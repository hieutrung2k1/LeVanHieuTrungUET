package Project1;


public class DictionaryCommandline {

    public static void showAllsWords() {

        int n = DictionaryManagement.n_word;
        System.out.println();
        System.out.printf("%-6s%-25s%s", "No", "| English", "| Vietnamese");
        System.out.println("\n");

        for(int i = 0; i < n; ++i) {
            System.out.printf("%-6s%-25s%s", (i+1), "| " + Dictionary.words_target[i], "| " + Dictionary.words_explain[i]);
            System.out.println();
        }


    }

}
