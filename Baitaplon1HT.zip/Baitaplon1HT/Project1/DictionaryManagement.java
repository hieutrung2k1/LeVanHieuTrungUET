package Project1;

import java.io.*;
import java.util.*;
import java.lang.*;

public class DictionaryManagement {

    public static int n_word;

    public static File file = new File("C:\\Users\\Administrator\\IdeaProjects\\untitled6\\src\\Project1\\dictionaries");

    // dua du lieu tu ban phim
    public static void insertFromCommandline() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap so tu: ");
        n_word = Integer.parseInt(sc.nextLine());
        Word wd = new Word();
        String word_target;
        String word_explain;
        System.out.println("Danh sach tu va giai thich: ");
        for(int i = 0; i < n_word; ++i) {
            word_target = sc.nextLine();
            wd.setWord_target(word_target);
            Project1.Dictionary.words_target[i] = wd.getWord_target();
            word_explain = sc.nextLine();
            wd.setWord_explain(word_explain);
            Project1.Dictionary.words_explain[i] = wd.getWord_explain();
        }
    }

    // ham doc du lieu tu file
    public static void insertFromFile() {
        Scanner sc = null;

        String str = "", res = "";
        int a = 0, k = 0, a1 = 0;

        try {
            sc = new Scanner(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


        while(sc.hasNextLine()) {
            str = "";
            res = sc.nextLine();
            a = res.indexOf(' ');
            for(int i = 0; i < a; ++i) {
                str += res.charAt(i);
            }

            Project1.Dictionary.words_target[k] = str;
            str = "";
            for(int i = a + 1; i < res.length(); ++i) {
                str += res.charAt(i);
            }
            str = str.trim();
            Project1.Dictionary.words_explain[k] = str;
            ++k;
//
//            res = sc.nextLine();
//            a = res.indexOf(' ');
//            str = res.substring(0, a);
//            Dictionary.words_target[k] = str;
//            str = res.substring(a+1);
//            str = str.trim();
//            Dictionary.words_explain[k] = str;
//            ++k;

        }
        n_word = k;
    }

    // ham tra cuu tu
    public static String dictionaryLookup(String word_need_look) {

        for(int i = 0; i < n_word; ++i) {
            if(word_need_look.compareTo(Project1.Dictionary.words_target[i]) == 0) {
                return Project1.Dictionary.words_explain[i];
            }
        }

        return "There is no word to find!";

    }

    public static int d;

    public static String[] dictionarySearch() {
        Scanner sc = new Scanner(System.in);

        String[] result_need_search = new String[100000];
        d = 0;

        System.out.println("Nhap tu can tra bat dau bang: ");
        String word_need_search = sc.nextLine();

        for(int i = 0; i < n_word; ++i) {
            if(Dictionary.words_target[i].indexOf(word_need_search) == 0) {
                result_need_search[d] = Project1.Dictionary.words_target[i];
                ++d;
            }
        }
        return result_need_search;
    }


    public static void addWord(String word_add_target, String word_add_explain) throws IOException {

        FileWriter fileWriter = new FileWriter("C:\\Users\\Administrator\\IdeaProjects\\untitled6\\src\\Project1\\dictionaries", true); // set true for append mode
        PrintWriter printWriter = new PrintWriter(fileWriter);
//        printWriter.println(word_add_target + "    " + word_add_explain); // new line

        insertFromFile();
        for (int i = 0; i < n_word; ++i) {
            if (Dictionary.words_target[i].contentEquals(word_add_target)) {
                return;
            }
        }
        printWriter.printf("%-15s%s", word_add_target, word_add_explain + "\n");
        printWriter.close();
        insertFromFile();
    }

    public static boolean editWord(String word_need_edit, String word_edit, String explain_edit) throws IOException {

        for(int i = 0; i < n_word; ++i) {
            if(Project1.Dictionary.words_target[i].indexOf(word_need_edit) >= 0) {
                Project1.Dictionary.words_target[i] = word_edit;
                Project1.Dictionary.words_explain[i] = explain_edit;
                // sau khi sua thi ghi lai vao file
                PrintWriter writer1 = null;
                writer1 = new PrintWriter(file);
                for (int z = 0; z < n_word; ++z) {
                    writer1.printf("%-15s%s", Dictionary.words_target[z], Dictionary.words_explain[z] + "\n");
                }
                writer1.flush();
                writer1.close();
                return true;
            }
        }
        return false;
    }

    public static void delWord(String word_need_del) throws IOException {
//        Scanner sc = new Scanner(System.in);
//
//        System.out.println("Nhap tu can xoa: ");
//        String word_need_del = sc.nextLine();
        int i, c = 0;
        for(c = i = 0; i < n_word; ++i) {
            if(Dictionary.words_target[i].indexOf(word_need_del) == -1) {
                Dictionary.words_target[c] = Dictionary.words_target[i];
                Dictionary.words_explain[c] = Dictionary.words_explain[i];
                ++c;
            }
        }
        n_word = c;

        PrintWriter writer1 = null;
        writer1 = new PrintWriter(file);
        for (int z = 0; z < n_word; ++z) {
            writer1.printf("%-15s%s", Dictionary.words_target[z], Dictionary.words_explain[z] + "\n");
        }
        writer1.flush();
        writer1.close();


    }

    public static void dictionaryExportToFile() throws IOException {

//        File files = new File("C:\\Users\\Administrator\\IdeaProjects\\untitled6\\src\\Project1\\files");

        PrintWriter writer1 = null;
//        printWriter.printf("%-15s%s", word_add_target, word_add_explain + "\n");
        writer1 = new PrintWriter(new File("C:\\Users\\Administrator\\IdeaProjects\\untitled6\\src\\Project1\\files"));
        for (int i = 0; i < n_word; ++i) {
            writer1.printf("%-15s%s", Dictionary.words_target[i], Dictionary.words_explain[i] + "\n");
        }
        writer1.flush();
        writer1.close();


    }

}
