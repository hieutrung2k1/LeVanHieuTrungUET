package Project1;

import java.io.*;
import java.util.Scanner;

public class DictionaryCommandLine1 {

    public static Scanner scanner = new Scanner(System.in);

    public static void dictionaryBasic() {

        DictionaryManagement.insertFromCommandline(); // nhập dữ liệu từ bàn phím
        DictionaryCommandline.showAllsWords();

    }

    public static void dictionaryAdvance() {

        DictionaryManagement.insertFromFile(); // đọc dữ liệu từ file
        DictionaryCommandline.showAllsWords(); // hiển thị danh sách

        // nhap tu can tra cuu
        System.out.println("Nhap tu can tim: ");
        String word_need_look = scanner.nextLine();

        System.out.println(DictionaryManagement.dictionaryLookup(word_need_look));

    }

    public static void changeData() throws IOException {
        System.out.println("Nhap tu can them: " );
        String word_add_target = scanner.nextLine();
        String word_add_explain = scanner.nextLine();
        DictionaryManagement.addWord(word_add_target, word_add_explain); // thêm từ vào file
        System.out.println("Nhap tu can sua: ");
        String word_need_edit = scanner.nextLine();
        System.out.println("Sua thanh: " );
        String word_edit = scanner.nextLine();
        String explain_edit = scanner.nextLine();
        if (DictionaryManagement.editWord(word_need_edit, word_edit, explain_edit)) {
            System.out.println("Sua thanh cong!");
        }
        else {
            System.out.println("Khong co tu can sua!");
        }
        System.out.println("Nhap tu can xoa: " );
        String word_need_del = scanner.nextLine();
        DictionaryManagement.delWord(word_need_del); // xóa từ
        DictionaryCommandline.showAllsWords();
    }

    // in ra danh sách những từ cần tra
    public static void dictionarySearcher() {
        String[] result_search = DictionaryManagement.dictionarySearch();
        System.out.println("Danh sach nhung tu can tra: ");

        for(int i = 0; i < DictionaryManagement.d; ++i) {
            System.out.println(result_search[i]);
        }
    }
}
