package Project1;

public class Dictionary {

    int n = DictionaryManagement.n_word; // so luong word

    public static String[] words_target = new String[500000];
    public static String[] words_explain = new String[500000];


}
