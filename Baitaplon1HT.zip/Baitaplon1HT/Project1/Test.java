package Project1;

import Graphic.DictionaryApplication;
import javafx.event.ActionEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Scanner;

public class Test {

    public static void main(String[] args) throws IOException {

        Scanner sc = new Scanner(System.in);

        System.out.println("1. Nhap tu ban phim (1)");
        System.out.println("2. Lay tu file (2)");
//        System.out.println("3. Hien thi do hoa (3)");
        System.out.println("Nhap lua chon: ");
        int select = sc.nextInt();
        if(select == 1) {
            DictionaryCommandLine1.dictionaryBasic();
        }
        else if(select == 2) {
            DictionaryCommandLine1.dictionaryAdvance();
            DictionaryCommandLine1.changeData();
            DictionaryCommandLine1.dictionarySearcher();
            DictionaryManagement.dictionaryExportToFile();
        }

    }

}
