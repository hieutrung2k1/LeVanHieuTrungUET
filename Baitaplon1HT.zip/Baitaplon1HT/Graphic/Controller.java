package Graphic;

import Project1.Dictionary;
import Project1.DictionaryManagement;
import com.sun.speech.freetts.Voice;
import de.dfki.lt.freetts.ClusterUnitVoice;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;

import com.sun.speech.freetts.VoiceManager;
import com.sun.speech.freetts.Voice;


public class Controller {

    @FXML
    private TextField Word;
    @FXML
    private TextField Word1;
    @FXML
    private TextField Word2;
    @FXML
    private TextArea textArea;
    @FXML
    private Button search;
    @FXML
    private Button delete;
    @FXML
    private Button edit;
    @FXML
    private Button add;
    @FXML
    private Button speak;



    public static File file = new File("C:\\Users\\Administrator\\IdeaProjects\\untitled6\\src\\Project1\\dictionaries");


    public void changeScreenButtonAdd(ActionEvent event) throws IOException {
        Parent parentView = FXMLLoader.load(getClass().getResource("addword.fxml"));
        Scene sceneView = new Scene(parentView);

        // this line gets the Stage information
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setScene(sceneView);
        window.show();

    }

    public void changeScreenButtonAddRe(ActionEvent event) throws IOException {
        Parent parentView = FXMLLoader.load(getClass().getResource("/Graphic/sample.fxml"));
        Scene sceneView = new Scene(parentView);

        /* this line gets the Stage information */
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setScene(sceneView);
        window.show();

    }

    public void changeScreenButtonEdit(ActionEvent event) throws IOException {
        Parent parentView = FXMLLoader.load(getClass().getResource("editword.fxml"));
        Scene sceneView = new Scene(parentView);

        // this line gets the Stage information
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setScene(sceneView);
        window.show();

    }

    public void changeScreenButtonEditRe(ActionEvent event) throws IOException {
        Parent parentView = FXMLLoader.load(getClass().getResource("sample.fxml"));
        Scene sceneView = new Scene(parentView);

        // this line gets the Stage information
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setScene(sceneView);
        window.show();

    }

    public void changeScreenButtonDelete(ActionEvent event) throws IOException {
        Parent parentView = FXMLLoader.load(getClass().getResource("deleteword.fxml"));
        Scene sceneView = new Scene(parentView);

        // this line gets the Stage information
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setScene(sceneView);
        window.show();

    }

    public void changeScreenButtonDeleteRe(ActionEvent event) throws IOException {
        Parent parentView = FXMLLoader.load(getClass().getResource("sample.fxml"));
        Scene sceneView = new Scene(parentView);

        // this line gets the Stage information
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setScene(sceneView);
        window.show();

    }
    public void changeScreenButtonSearch(ActionEvent event) throws IOException {
        Parent parentView = FXMLLoader.load(getClass().getResource("search.fxml"));
        Scene sceneView = new Scene(parentView);

        // this line gets the Stage information
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setScene(sceneView);
        window.show();

    }

    public void changeScreenButtonSearchRe(ActionEvent event) throws IOException {
        Parent parentView = FXMLLoader.load(getClass().getResource("sample.fxml"));
        Scene sceneView = new Scene(parentView);

        // this line gets the Stage information
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setScene(sceneView);
        window.show();

    }

    private static String text = "";


    @FXML
    private void Search(ActionEvent event) throws IOException {
        DictionaryManagement.insertFromFile();
        String word_need_look = Word.getText().trim();
        String word = DictionaryManagement.dictionaryLookup(word_need_look);

        Controller.text = word_need_look;

        if (word == "There is no word to find!") {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(word);
            textArea.clear();
            alert.show();
            Word.clear();
        }
        else {
            textArea.clear();
            textArea.setText(word);
        }
    }

//    private String name;
//
//    private com.sun.speech.freetts.Voice voice;
//
//    public Controller(String name) {
//        this.name = name;
//        this.voice = VoiceManager.getInstance().getVoice(this.name);
//        this.voice.allocate();
//    }
//    @FXML
//    private void Speak(String something) throws IOException {
//        something = Controller.text;
//        this.voice.speak(something);
//    }

    @FXML
    private void Delete(ActionEvent event) throws IOException {
        DictionaryManagement.insertFromFile();
        String word_need_del = Word.getText().trim();
        String word = "There is no word to delete!";
        for(int i = 0; i < DictionaryManagement.n_word; ++i) {
            if(word_need_del.indexOf(Dictionary.words_target[i]) == 0) {
                word = "Deleted!";
                DictionaryManagement.delWord(word_need_del);
//                DictionaryManagement.dictionaryExportToFile();
            }
        }
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(word);
        alert.show();
        Word.clear();
    }
    @FXML
    private void Add(ActionEvent event) throws IOException {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        String word_add_target = Word.getText().trim();
        String word_add_explain = Word1.getText().trim();
        if (word_add_target == "" || word_add_explain == "") {
            alert.setHeaderText("There is no word to edit!");
        }
        else {
            DictionaryManagement.addWord(word_add_target, word_add_explain);
            alert.setHeaderText("Added!");
        }

//        DictionaryManagement.dictionaryExportToFile();



        alert.show();
        Word.clear();
        Word1.clear();

    }
    @FXML
    private void Edit(ActionEvent event) throws IOException {
        DictionaryManagement.insertFromFile();
        String word_need_edit = Word.getText().trim();
        String word_new = Word1.getText().trim();
        String explain_new = Word2.getText().trim();

        Alert alert = new Alert(Alert.AlertType.INFORMATION);

        if (word_need_edit == "" || word_new == "" || explain_new == "") {
            alert.setHeaderText("There is no word to edit!");
        }
        else if (word_need_edit != "" &&  word_new != "" && explain_new != "") {
            if (DictionaryManagement.editWord(word_need_edit, word_new, explain_new)) {
                alert.setHeaderText("Edited!");
            }
            else {
                alert.setHeaderText("There is no word to edit");
            }
        }
//        DictionaryManagement.dictionaryExportToFile();
        alert.show();
        Word.clear();
        Word1.clear();
        Word2.clear();
    }


}
