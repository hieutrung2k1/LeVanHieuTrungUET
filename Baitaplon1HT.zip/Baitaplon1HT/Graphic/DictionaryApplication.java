package Graphic;

import com.sun.javafx.fxml.FXMLLoaderHelper;
import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;
import de.dfki.lt.freetts.ClusterUnitVoice;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class DictionaryApplication extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws IOException {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
            primaryStage.setTitle("DICTIONARY");
            Scene scene = new Scene(root, 691, 433);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

//        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
//        primaryStage.setTitle("DICTIONARY");
//        Scene scene = new Scene(root, 691, 433);
//        primaryStage.setScene(scene);
//        primaryStage.show();



    }
}
